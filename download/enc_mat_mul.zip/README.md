# diag_mat_mul

### Running Instructions

1. ##### System Requirements

   Ubuntu22

2. ##### Steps

   - Place the `test_enc_mat_mul` file in your Ubuntu system.

   - Provide executable permissions to the file.

     ```bash
     chmod +x test_enc_mat_mul
     ```

   - Execute the binary file.

     ```bash
     ./test_enc_mat_mul
     ```


### Test Instructions

Once the file is executed, it will output the following information:

```bash
Examples:

  1.  Coprime matrix multiplication base
  2.  Jiang matrix multiplication base
  3.  Lu matrix multiplication base
  4.  R-T matrix multiplication base
  5.  Block matrix multiplication by LongRot action
  6.  Block matrix multiplication strassen and naive(jiang)
  7.  Block matrix multiplication strassen and naive(coprime)
  8.  Base matrix multiplication in Table 8
  9.  Base matrix multiplication in Table 9
 10.  Block matrix multiplication in Table 10
 11.  Block matrix multiplication in Table 11
 12.  Block matrix multiplication in Table 12
 13.  Block matrix multiplication in Table 13
 14.  Block matrix multiplication in Table 14
 0. Exit
```

In this case, `case 1-7` refer to the basic test cases, while `case 8-14` include all the scenarios from Table 8 to Table 14. Here, ($n$,$m$,$p$) represents matrices $A\in \mathcal{R}^{n \times m}$ and $B\in \mathcal{R}^{m \times p}$. The specific test scenarios are as follows:

1. `case 1`:

   - `Diag encode matrix multiplication`: ($44$, $45$, $43$)
   - `Diag encode matrix multiplication`: ($61$, $64$, $63$)
   - `Diag encode matrix multiplication`: ($29$, $128$, $31$)
   - `Diag encode matrix multiplication`: ($89$, $91$, $90$)

2. `case 2`:

   - `Jiang matrix multiplication`: ($64$,$64$,$64$)
   - `Jiang matrix multiplication`: ($128$,$128$,$128$) | $N=32768$

3. `case 3`:

   - `Lu matrix multiplication segment 8`: ($16$,$16$,$5 \times 4096$)
   - `Lu matrix multiplication not segment`: ($16$,$16$,$5 \times 4096$)
   - `Lu matrix multiplication segment 8`: ($64$,$64$,$5 \times 4096$)
   - `Lu matrix multiplication not segment`: ($64$,$64$,$5 \times 4096$)

4. `case 4`:

   - `R-T matrix multiplication`: ($16$,$16$,$16$)

5. `case 5`:

   - `Diag LongRot matrix multiplication with pre-generate`: ($256$, $257$, $17$)
   - `Diag LongRot matrix multiplication with pre-generate`: ($256$, $17$, $257$)
   - `Diag LongRot matrix multiplication`: ($256$, $257$, $17$)
   - `Diag LongRot matrix multiplication`: ($256$, $17$, $257$)

6. `case 6`:

   - `Jiang naive block matrix multiplication`: ($64$,$64$,$64$)$\times 4$
   - `Jiang strassen block matrix multiplication`: ($64$,$64$,$64$)$\times 4$
   - `Jiang naive block matrix multiplication`: ($64$,$64$,$64$)$\times 8$
   - `Jiang strassen block matrix multiplication`: ($64$,$64$,$64$)$\times 8$

7. `case 7`:

   - `Diag encode naive block matrix multiplication`: ($44$, $45$, $43$)$\times 4$
   - `Diag encode strassen block matrix multiplication`: ($44$, $45$, $43$)$\times 4$
   - `Diag encode naive block matrix multiplication`: ($44$, $45$, $43$)$\times 8$
   - `Diag encode strassen block matrix multiplication`: ($44$, $45$, $43$)$\times 8$

8. `case 8`:

   - `R-T matrix multiplication`: ($16$,$16$,$16$)
   - `Diag encode matrix multiplication`: ($16$, $19$, $17$)  | $\log q=170$
   - `Diag encode matrix multiplication`: ($16$, $19$, $17$)  | $\log q=140$

9. `case 9`:

   - `Jiang matrix multiplication`: ($64$,$64$,$64$)

   - `Jiang matrix multiplication`: ($128$,$128$,$128$) | $N=32768$

     

   - `Diag encode matrix multiplication`: ($44$, $45$, $43$)

   - `Diag encode matrix multiplication`: ($61$, $64$, $63$) | $N=16384$

   - `Diag encode matrix multiplication`: ($89$, $91$, $90$) | $N=32768$

10. `case 10`:

    - `Jiang naive block matrix multiplication`: ($64$,$64$,$64$)$\times 4$

    - `Jiang naive block matrix multiplication`: ($128$,$128$,$128$)$\times 2$ | $N=32768$

    - `Jiang strassen block matrix multiplication`: ($64$,$64$,$64$)$\times 4$

    - `Jiang strassen block matrix multiplication`:  ($128$,$128$,$128$)$\times 2$ | $N=32768$

      

    - `Diag encode naive block matrix multiplication`: ($44$, $45$, $43$)$\times 6$

    - `Diag encode naive block matrix multiplication`: ($88$, $89$, $87$)$\times 3$ | $N=32768$

    - `Diag encode strassen block matrix multiplication`: ($44$, $45$, $43$)$\times 8$

    - `Diag encode strassen block matrix multiplication`: ($64$, $65$, $67$)$\times 4$ | $N=32768$

    - `Diag LongRot matrix multiplication with pre-generate`: ($256$, $259$, $257$)

      

    - `Diag LongRot matrix multiplication`: ($256$, $259$, $257$) | $N=32768$

11. `case 11`:

    - `Jiang naive block matrix multiplication`: ($64$,$64$,$64$)$\times 8$

    - `Diag encode naive block matrix multiplication`: ($44$, $45$, $43$)$\times 12$

    - `Jiang strassen block matrix multiplication`: ($64$,$64$,$64$)$\times 8$

    - `Diag encode strassen block matrix multiplication`: ($44$, $45$, $43$)$\times 16$

    - `Diag LongRot matrix multiplication with pre-generate`: ($512$, $515$, $513$)

      

    - `Jiang naive block matrix multiplication`: ($64$,$64$,$64$)$\times 16$

    - `Diag encode naive block matrix multiplication`: ($44$, $45$, $43$)$\times 24$

    - `Jiang strassen block matrix multiplication`: ($64$,$64$,$64$)$\times 16$

    - `Diag encode strassen block matrix multiplication`: ($32$, $35$, $33$)$\times 32$ | $\log q=150$

    - `Diag LongRot matrix multiplication with pre-generate`: ($1024$, $1027$, $1025$)

12. `case 12`:

    - `Diag LongRot matrix multiplication with pre-generate`: ($256$, $257$, $17$)
    - `Diag LongRot matrix multiplication with pre-generate`: ($256$, $17$, $257$)
    - `Diag LongRot matrix multiplication with pre-generate`: ($1024$, $1025$, $17$)
    - `Diag LongRot matrix multiplication with pre-generate`: ($1024$, $17$, $1025$)
    - `Diag LongRot matrix multiplication with pre-generate`: ($2048$, $2049$, $11$)
    - `Diag LongRot matrix multiplication with pre-generate`: ($2049$, $8$, $2051$)

13. `case 13`:

    - `Jiang naive block matrix multiplication`: ($4$,$1636$,$5$)

    - `Jiang naive block matrix multiplication`: ($8$,$3045$,$9$)

    - `Jiang naive block matrix multiplication`: ($16$,$6093$,$17$)

    - `Jiang naive block matrix multiplication`: ($32$,$13847$,$33$)

      

    - `Diag encode naive block matrix multiplication`: ($4$,$1636$,$5$)

    - `Diag encode naive block matrix multiplication`: ($8$,$3045$,$9$)

    - `Diag encode naivee block matrix multiplication`: ($16$,$6093$,$17$)

    - `Diag encode naive block matrix multiplication`: ($32$,$13847$,$33$)

14. `case 14`:

    - `Jiang naive block matrix multiplication`: ($4$,$5$,$1636$)

    - `Jiang naive block matrix multiplication`: ($8$,$9$,$3405$)

    - `Jiang naive block matrix multiplication`: ($16$,$17$,$6093$)

    - `Jiang naive block matrix multiplication`: ($32$,$33$,$13847$)

      

    - `Diag encode naive block matrix multiplication`: ($4$,$5$,$1636$)

    - `Diag encode naive block matrix multiplication`: ($8$,$9$,$3405$)

    - `Diag encode naivee block matrix multiplication`: ($16$,$17$,$6093$)

    - `Diag encode naive block matrix multiplication`: ($32$,$33$,$13847$)

      

    - `Lu matrix multiplication segment 8`:  ($4$,$5$,$1636$)

    - `Lu matrix multiplication segment 8`:  ($8$,$9$,$3405$)

    - `Lu matrix multiplication segment 8`:  ($16$,$17$,$6093$)

    - `Lu matrix multiplication segment 8`:  ($32$,$33$,$13847$)
