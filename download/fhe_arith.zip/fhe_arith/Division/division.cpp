/* Copyright (C) 2016 Chen Xu
                 2017 Jingwei Chen
   Distributed under the terms of the GPLv3 license (see LICENSE file)
*/

/* 
	division.cpp is used to test binary division for positive integers within 4 bits
*/

#include <NTL/ZZ.h>
//support multithread computation
#include <NTL/BasicThreadPool.h>



#include <iostream>
#include <deque>
#include <cstdio>
#include <bitset>

//for counting the cost time under multithread compuation
#include <chrono>

#include "EncryptedArray.h"
#include "EncNum.h"

using namespace std;
using namespace NTL;


//If CLA is needed, then set bitN=64.
const int bitN = 4;

// Helper routines for packing data, you may ignore this at first
// and focus on main function
template<std::size_t B>
long bitset_to_long(const std::bitset<B>& b) {
  struct {long x:B;} s;
  return s.x = b.to_ulong();
}

template <typename T>
const deque<T> unpackData(long long num)  {
    // We unpack the integer into bits with 2's complement
    // representation
    deque<T> dataBits(bitN, 0);
    bitset<bitN> vecBits(num);
    for(int i = 0; i < bitN; ++i)  {
        dataBits[i] = (T)vecBits[i];
    }
    return dataBits;
}

const long long packData(const deque<int> & dataBits)  {
    // We unpack the integer into bits with 2's complement
    // representation
    long long res;
    bitset<bitN> vecBits;
    for(int i = 0; i < bitN; ++i)  {
        vecBits[i] = dataBits[i];
    }
    res = bitset_to_long(vecBits);
    return res;
}

void displayBits(const deque<int> & dataBits)  {
    deque<int>::const_reverse_iterator pos;
    for(pos = dataBits.rbegin(); pos != dataBits.rend(); ++pos) {
        cout << *pos;
    }
    cout << endl;
}

int main(int argc, char **argv)  {
    cout << endl;
    cout << "*********************************************************************" << endl;
    cout << "**       Homomorphic-Encryption Division For "<< bitN << "-Bit Integers        **" << endl;
    cout << "*********************************************************************" << endl;
     
///step 1: HElib initialzation
    
        auto start = std::chrono::system_clock::now();

	long w=64;          // Hamming weight of secret key
	ArgMapping amap;
	
	long m = 0;
	amap.arg("m", m, "phim");
	
	long p=2;
	amap.arg("p", p, "plaintext base");

	long r=1;
	amap.arg("r", r,  "lifting");

	long d=0;
	amap.arg("d", d, "degree of the field extension");
	amap.note("d == 0 => factors[0] defines extension");

	long c=3;
	amap.arg("c", c, "number of columns in the key-switching matrices");

	long k=80;
	amap.arg("k", k, "security parameter");

	long L=21;
	amap.arg("L", L, "# of levels in the modulus chain");

        long nthreads=4;	
        amap.arg("nthreads", nthreads, "number of threads");

        amap.parse(argc, argv);  
	if (m == 0)
		m = FindM(k,L,c,p, d, 0, 0);
    
        

    //cout << "m = " << m << endl;


        SetNumThreads(nthreads);
       
    // initialize context
    FHEcontext context(m, p, r);
    // modify the context, adding primes to the modulus chain
    buildModChain(context, L, c);
    // construct a secret key structure
    FHESecKey secretKey(context);
    // an "upcast": FHESecKey is a subclass of FHEPubKey
    const FHEPubKey& publicKey = secretKey;

    ZZX G;
    if (d == 0)
		G = context.alMod.getFactorsOverZZ()[0];
    else
		G = makeIrredPoly(p, d); 
	//cout << "G = " << G << endl;

	// actually generate a secret key with Hamming weight w
    secretKey.GenSecKey(w);
    
    cout << "Generating key-switching matrices... ";
    addSome1DMatrices(secretKey); // compute key-switching matrices that we need
    cout << "Done!" << endl;


    // constuct an Encrypted array object ea that is
    // associated with the given context and the polynomial G
    EncryptedArray ea(context, G);


    long nslots = ea.size();
    //cout << "num of slots is:" << nslots << endl;
    
    auto end = std::chrono::system_clock::now();
    std::chrono::duration<double> diff = end - start;
    cout <<"Addition initialization costs "<< diff.count() << " seconds." << endl;

    long long i, op1, op2, myRes;
    cout << "Input the 1st number:" << endl;
    cin >> op1;
    cout << "Input the 2nd number: " << endl;
    cin >> op2;

    myRes = op1 / op2;
    long myRes2 = op1 - myRes * op2;
    //myRes = op1 * op2;
    cout << "The quotient should be " << myRes << endl;
    cout << "The remainder should be " << myRes2 << endl;

///step 2: EncNum Construction


    start = std::chrono::system_clock::now();
    const int n = bitN;
    deque<int> vOp1(n,0);
    deque<int> vOp2(n,0);

    vOp1 = unpackData<int>(op1);
    vOp2 = unpackData<int>(op2);

    deque<Ctxt> Ctxt_vectorOp1;
    deque<Ctxt> Ctxt_vectorOp2;
    deque<Ctxt> Ctxt_vectorSum;

    vector<long> v(nslots,0);
    vector<long> v0(nslots,0);
    vector<long> v1(nslots,1);

    Ctxt ct0(publicKey);
    ea.encrypt(ct0, publicKey, v0);
    //cout << ct0.findBaseLevel() << endl;
    Ctxt ct1(publicKey);
    ea.encrypt(ct1, publicKey, v1);
    deque<Ctxt> Ctxt_Zero_One{ct0, ct1};
    deque<Ctxt> dR(n, ct0);

    for(i = 0; i < n; i++) {
        v[0] = vOp1[i];
        Ctxt ct(publicKey);
        ea.encrypt(ct, publicKey, v);
        Ctxt_vectorOp1.push_back(ct);
    }

    for(i = 0; i < n; i++) {
        v[0]=vOp2[i];
        Ctxt ct(publicKey);
        ea.encrypt(ct, publicKey, v);
        Ctxt_vectorOp2.push_back(ct);
    }

    // construction
    EncNum<Ctxt> a1(Ctxt_vectorOp1); // constructor
    EncNum<Ctxt> a2, a3, R;
    a2.init(Ctxt_vectorOp2); // another constructor
    a1.setOne(Ctxt_Zero_One);
    a2.setOne(Ctxt_Zero_One);
    R.init(dR);
    //a3.init(Ctxt_vectorOp2); // another constructor
    
    
    end = std::chrono::system_clock::now();
    diff = end - start;
    cout <<"Encryption and construction for homomorphic operation costs "<<diff.count() << " seconds." << endl;

    

///step 2.5 Testing
	deque<Ctxt> allOne(n, ct1);
	deque<Ctxt> allZero;
	
	//allZero = a1.add1bit(a1.getVec(), ct1);
	//allZero = a1.Cond(ct0, a1.getVec(), a2.getVec());

    
///step 3: EncNum Arithematic

   // t = clock();
      start = std::chrono::system_clock::now();

	// you may try a1-a2 and a1*a2 here
	// but remember the data range is -2^(n-1) to 2^(n-1) -1
    //a3 = a1 + a2;
    //a2.cla(a1);
    //a3.cla(a2);
    a3 = a1.DivWithReminder(a1, a2, R);



        end = std::chrono::system_clock::now();
        diff = end - start;

    cout <<"Calculating costs "<<diff.count() << " seconds." << endl;
/* 
    t = clock();

	// you may try a1-a2 and a1*a2 here
	// but remember the data range is -2^(n-1) to 2^(n-1) -1
    a2.cla(a1);
    a3.cla(a2);

    t = clock() - t;

    cout <<"calculating time="<<((float)t)/CLOCKS_PER_SEC << "s" << endl;    
 */ 
    
///step 4: decryption and from bin to decimal

	
        start = std::chrono::system_clock::now();
    vector<long> res;
    Ctxt_vectorSum = a3.getVec();
    
/*    
    // test level
    cout << "start testing" << endl;
    cout << endl;
    long level = 0;
    Ctxt MSB = ct0;
    for(auto iter = Ctxt_vectorSum.begin(); iter != Ctxt_vectorSum.end(); ++iter) {
		level = iter->findBaseLevel();
		cout << "level  =  " << level << endl << endl;
	}
    //Ctxt_vectorSum = allZero;
*/
    long long tmp=0;
    deque<int> vf(n,0);

    // display and caculate Ctxt decimal results
    for(i=0;i<n;i++){
        ea.decrypt(Ctxt_vectorSum[i], secretKey, res);
        vf[i]=res[0];
    }

    tmp = packData(vf);
    //
        end = std::chrono::system_clock::now();
       diff = end - start;
    cout <<"Decryption and convertion from binary to decimal costs "<<diff.count() << " seconds." << endl;
    
    cout<<"The decrypted binary quotient is: "<<endl;
    displayBits(vf);
    cout << "The decimal quotient  is " << tmp;
    if(tmp == myRes)
		cout << " ... Correct!" << endl;
	else
		cout << "... wrong answer!" << endl;  



    Ctxt_vectorSum = R.getVec();
    for(i=0;i<n;i++){
        ea.decrypt(Ctxt_vectorSum[i], secretKey, res);
        vf[i]=res[0];
    }

    tmp = packData(vf);
    //

    cout<<"The decrypted binary remainder is: "<<endl;
    displayBits(vf);
    cout << "The decimal remainder  is " << tmp;
    if(tmp == myRes2)
                cout << " ... Correct!" << endl;
        else
                cout << "... wrong answer!" << endl;



//	Ctxt_vectorSum = a1.getVec();
 /*
    // test level
    for(auto iter = Ctxt_vectorSum.begin(); iter != Ctxt_vectorSum.end(); ++iter) {
		level = iter->findBaseLevel();
		cout << "level  =  " << level << endl << endl;
	}

	// display and caculate Ctxt decimal results
    for(i=0;i<n;i++){
        ea.decrypt(Ctxt_vectorSum[i], secretKey, res);
        vf[i]=res[0];
    }

    tmp = packData(vf);
    //
    cout<<"the binary result is: "<<endl;
    displayBits(vf);
    cout << "decryption result is :" << tmp;
    if(tmp == myRes2)
		cout << "... correct!" << endl;
	else
		cout << "... wrong answer!" << endl;  

    */

    return 0;
 
}
