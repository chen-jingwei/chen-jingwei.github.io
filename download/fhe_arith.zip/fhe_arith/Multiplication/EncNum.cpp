//  Copyright (C) 2016 Chen Xu
//	Distributed under the terms of the GPLv3 license (see LICENSE file)

/*
    EncNum is used for Binary Arithmetics, particularly designed for
    homomorphic encryption library HElib, you can try this along with
    Ctxt class in HElib.
*/

#include "EncNum.h"
#include <cmath>
#include <sys/time.h>


/*
    If 64 bit-CLA is needed, then open the following two "#define".
*/
//#define _64_BIT
//#define _CLA

#ifdef _64_BIT
const int bitN = 64;
//extern const int bitN = 64;
#else //16bit
const int bitN = 16;
//extern const int bitN = 16;
#endif

const int groupSize = 4;
/*
    NOTE about Number Representation: we use
        1. little endian represntation
        2. 2's complement
        3. all the operations are binary

    like below:

                     ------------------->
    array  [0]    [1]    [2]       ....    [n-2]          [n-1]
           2^0    2^1    2^2               2^(n-2) MSB    sign

*/

/*
  '+' here means XOR and '*' means AND

  Refer to wikipedia "adder" item
  https://en.wikipedia.org/wiki/Adder_(electronics)
*/

/*
  Half Adder routines

  the sum of current bit:      S = A + B
  the carryout of current bit: Cout = A * B
*/

template <typename T>
const T EncNum<T>::add_first_sum(const T & bitA ,const T & bitB) const {

    T bitSum = bitA;
    bitSum.addCtxt(bitB);
    return bitSum;
}


template <typename T>
const T EncNum<T>::add_first_carryout(const T & bitA,const T & bitB) const {

    T bitAxB = bitA;
    bitAxB.multiplyBy(bitB);
    return bitAxB;
}

/*
  Full Adder routines

  the sum of current bit:      S = A + B + Cin
  the carryout of current bit: Cout = A*B + B*Cin + Cin*A
*/

template <typename T>
const T EncNum<T>::add_sum(const T & bitA ,const T & bitB,const T & bitCin) const {

    T bitSum = bitA;
    bitSum.addCtxt(bitB);
    bitSum.addCtxt(bitCin);
    return bitSum;
}

template <typename T>
const T EncNum<T>::add_carryout(const T & bitA,const T & bitB,const T & bitCin) const {

    T bitAxB = bitA;
    bitAxB.multiplyBy(bitB);
    T bitBxC = bitB;
    bitBxC.multiplyBy(bitCin);
    T bitCxA = bitCin;
    bitCxA.multiplyBy(bitA);
    // gather the result
    T bitCout = bitAxB;
    bitCout.addCtxt(bitBxC);
    bitCout.addCtxt(bitCxA);
    return bitCout;
}

/* improved one-bit full adder: 
 * https://eprint.iacr.org/2009/411.pdf
 * the carryout of current bit: Cout = (A + Cin) * (B + Cin) +Cin
 */
 
template <typename T>
const T EncNum<T>::add_carryout_improved(const T & bitA,const T & bitB,const T & bitCin) const {

    T bitA_plus_Cin = bitA;
    bitA_plus_Cin.addCtxt(bitCin);
    T bitB_plus_Cin = bitB;
    bitB_plus_Cin.addCtxt(bitCin);
    T bitProd = bitA_plus_Cin;
    bitProd.multiplyBy(bitB_plus_Cin);
    // gather the result
    T bitCout = bitProd;
    bitCout.addCtxt(bitCin);
    return bitCout;
}

/*
  N-bit numbers Adder
  using Ripple-carry adder
  Refer to: https://en.wikipedia.org/wiki/Adder_(electronics)
*/
template <typename T>
deque<T> EncNum<T>::rca_deque(const deque<T>& a, const deque<T>& b) {

    int n = a.size();
    deque<T> sum;
    // Do the first bit addition without carryin
    T ctSum = add_first_sum(a[0], b[0]);
    T ctCarryin = add_first_carryout(a[0], b[0]);
    sum.push_back(ctSum);

    for(int i = 1; i < n-1; ++i)
    {
        ctSum = add_sum(a[i], b[i],ctCarryin);
        //ctCarryin = add_carryout(this->vNum[i], rhs.vNum[i],ctCarryin);
        ctCarryin = add_carryout_improved(a[i], b[i],ctCarryin);
        sum.push_back(ctSum);
    }
    ctSum = add_sum(a[n-1], b[n-1],ctCarryin);
    sum.push_back(ctSum);
    
    return sum;
}

template <typename T>
void EncNum<T>::rca_shift(deque<T>& a, const deque<T>& b, int shift1, int shift2) {
    int n = a.size();
    int delta = shift2 - shift1;
    int round = n - shift2;
    //cout << "n = " << n << ", delta = " << delta << ", round = " << round << endl;
    deque<T> sum;
    // Do the first bit addition without carryin
    T ctSum = add_first_sum(a[delta], b[0]);
    T ctCarryin = add_first_carryout(a[delta], b[0]);
    a[delta] = ctSum;

    for(int i = 1; i < round - 1; ++i)
    {
        ctSum = add_sum(a[i+delta], b[i],ctCarryin);
        ctCarryin = add_carryout_improved(a[i+delta], b[i],ctCarryin);
        a[i+delta] = ctSum;
    }
    ctSum = add_sum(a[round-1+delta], b[round-1],ctCarryin);
    a[round-1+delta] = ctSum;
}

/////////////////////////////////////////////

template <typename T>
const deque<T> EncNum<T>::recursiveGP(const deque<T> &gp)  {
	int bn = gp.size() / 2; // length of g and p
	int n = bn / groupSize; // output length
	//cout << "n = " << n << endl;
	int p, g;  // index
	//T tmp = gp[0];
	//tmp += tmp;
	T tmp = vZero_One[0];
	T tempg = tmp, tempp = tmp, tmp1 = tmp, tmp2 = tmp;
    deque<T> ggp(2*n, tmp);
    int i = 0;
    int first = 0, last = n;

    for(i = first; i < last; i++) {
		g = 4 * i;  	// g
		p = g + bn;     // p
		
		tmp1 = gp[p+3];
		tmp1.multiplyBy(gp[p+2]);  //p3p2
		tmp2 = gp[p+1];
		tmp2.multiplyBy(gp[g+0]); //p1g0
		tmp2.multiplyBy(tmp1);   //p3p2p1g0
		tmp1.multiplyBy(gp[g+1]);   // p3p2g1
		tempg = gp[p+3];
		tempg.multiplyBy(gp[g+2]);
		tempg += gp[g+3];
		tempg += tmp1;
		tempg += tmp2;
		
		tempp = gp[p+3];
		tempp.multiplyBy(gp[p+2]);
		tmp1 = gp[p+1];
		tmp1.multiplyBy(gp[p+0]);
		tempp.multiplyBy(tmp1);
		
		ggp[i] = tempg;
		ggp[n + i] = tempp;
	}
    return ggp;
}


template <typename T>
void EncNum<T>::CalculateCarryin(const deque<T>& gp, deque<T>& Cin, int size)  {
	int bn = gp.size() / 2;
	assert(bn == 4*size);
	//T tmp = gp[0];
	//tmp += tmp;
	T tmp = vZero_One[0];
	T tmp1 = tmp, tmp2 = tmp, tmp3 = tmp, tmp4 = tmp, tmp5 = tmp, tmp6 = tmp, tmp7 = tmp, tmp8 = tmp, tmp9 = tmp;
	
	int g, p;
	int index = bitN/(groupSize*size);
	if(size == 1)  { //first time
		g = 0;  // g
		p = g + bn; // p
		tmp1 = gp[p+0];
		tmp1.multiplyBy(Cin[g+0]);  //p0Cin
		tmp2 = gp[p+2];
		tmp3 = gp[g+1];
		tmp6 = gp[p+3];
		tmp6.multiplyBy(tmp2);  //p3p2
		tmp3.multiplyBy(tmp2);  //p2g1
		tmp2.multiplyBy(gp[p+1]);  // p2p1
		tmp4 = gp[p+1];
		tmp4.multiplyBy(gp[g+0]); //p1g0
		tmp5 =tmp1;
		tmp5.multiplyBy(gp[p+1]); //p1p0Cin
		tmp7 = tmp2;
		tmp7.multiplyBy(gp[g+0]); //p2p1g0
		tmp8 = tmp2;
		tmp8.multiplyBy(tmp1);
		tmp9 = gp[p+3];
		tmp9.multiplyBy(gp[g+2]); // p3g2

		Cin[index] = gp[g+0];
		Cin[index] += tmp1;

		Cin[2*index] = gp[g+1];
		Cin[2*index] += tmp4;
		Cin[2*index] += tmp5;
		
		Cin[3*index] = gp[g+2];
		Cin[3*index] += tmp3;
		Cin[3*index] += tmp7;
		Cin[3*index] += tmp8;
				
		Cin[4*index] = gp[g+3];	
		Cin[4*index] += tmp9;
		tmp3.multiplyBy(gp[p+3]);
		Cin[4*index] += tmp3;
		tmp4.multiplyBy(tmp6);
		Cin[4*index] += tmp4;
		tmp6.multiplyBy(tmp5);
		Cin[4*index] += tmp5;
	}
	else {
		for(int i = 0; i < size; i++) {
			g = 4 * i;  // g
			p = g + bn; // p
			
			tmp1 = gp[p+0];
			tmp1.multiplyBy(Cin[g*index]);  //p0Cin
			tmp2 = gp[p+2];
			tmp3 = gp[g+1];
			tmp3.multiplyBy(tmp2);  //p2g1	
			tmp2.multiplyBy(gp[p+1]);  // p2p1
			tmp4 = gp[p+1];
			tmp4.multiplyBy(gp[g+0]); //p1g0
			tmp5 =tmp1;
			tmp5.multiplyBy(gp[p+1]); //p1p0Cin	
			tmp7 = tmp2;
			tmp7.multiplyBy(gp[g+0]); //p2p1g0
			
			
			Cin[(g+1)*index] = gp[g+0];
			Cin[(g+1)*index] += tmp1;
			
			
			Cin[(g+2)*index] = gp[g+1];
			Cin[(g+2)*index] += tmp4;
			Cin[(g+2)*index] += tmp5;
			
			  
			Cin[(g+3)*index] = gp[g+2];
			Cin[(g+3)*index] += tmp3;
			Cin[(g+3)*index] += tmp7;
			tmp2.multiplyBy(tmp1);
			Cin[(g+3)*index] += tmp2;
		}
	}
}

template <typename T>
deque<T> EncNum<T>::cla_deque(const deque<T>& a, const deque<T>& b, bool add)  {
	T tmp = vZero_One[0];
	deque<T> gp, ggp, sgp, sum;
	deque<T> Cin(bitN+1, tmp);
	if(add == false) {
		Cin.push_front(vZero_One[1]);
		Cin.pop_back();
	}
	deque<T> zero(1,tmp);

    //1. calculate gi and pi for all i. (1 gate delay)
    for(int i = 0; i < bitN; i++) {
		tmp = a[i];
		tmp.multiplyBy(b[i]);
		gp.push_back(tmp);
	}
	for(int i = 0; i < bitN; i++) {
		tmp = a[i];
		tmp += b[i];
		gp.push_back(tmp);
	}
	
	//2. calculate ggj and gpj for all j using gi and pi. (2 gate delays)
	ggp = recursiveGP(gp);

	#ifdef _64_BIT
    //3. Calculate sgk and spk for all k using ggj and gpj . (2 gate delays) Note, it is at this point, we
    //can shift to computing the top-level sectional carries. This is because the number of sections
    //is less than or equal the block size which is 4 bits.
    sgp = recursiveGP(ggp);

    //4. Calculate sc k using sg k and sp k for all k and 0 for sc i−1 . (2 gate delays)
    CalculateCarryin(sgp, Cin, 1);
	#endif

    //5. Calculate gc j using gg j , gp j and correct sc k , k = (j div 4) as sectional carry-in for all j. (2
    //gate delays)
    CalculateCarryin(ggp, Cin, bitN/16);
    
    //6. Calculate c i using g i , p i and correct gc j , j = (i div 4) as group carry-in for all i. (2 gate
    //delays)
    CalculateCarryin(gp, Cin, bitN/4);
    
    //7. Calculate sum i using ai xor bi xor ci for all i. (2 gate delays)
	for(int i = 0; i < bitN; i++) {
		tmp = gp[bitN + i];
		tmp += Cin[i];
		sum.push_back(tmp);
	}
	sum.push_back(Cin[bitN]);

	return sum;
}

template <typename T>
EncNum<T> & EncNum<T>::operator+=(const EncNum<T> &rhs) {
#ifdef _CLA
	this->vNum = cla_deque(this->vNum, rhs.vNum);
#else
	this->vNum = rca_deque(this->vNum, rhs.vNum);
#endif
	return *this;
}

template <typename T>
const EncNum<T> EncNum<T>::operator+(const EncNum<T> &other) const {
    return EncNum(*this) += other;
}

/////////////////////////////////////////////

/*
  '+' here means XOR and '*' means AND
  Refer to wikipedia "subtractor" item https://en.wikipedia.org/wiki/Subtractor
*/

/*
  Half Subtractor routines

  the difference of current bits:     D = A - B = A + B (note they are SAME for bit)
  the borrow out of current bits:     Bout = (!A) * B = (A+1)*B = A*B + B
*/

template <typename T>
const T EncNum<T>::subtract_first_difference(const T & bitA,const T & bitB) const {

    T ctSum = bitA;
    ctSum.addCtxt(bitB);
    return ctSum;
}

template <typename T>
const T EncNum<T>::subtract_first_borrow(const T & bitA, const T & bitB) const {

    T bitAxB = bitA;
    bitAxB.multiplyBy(bitB);
    bitAxB.addCtxt(bitB);
    return bitAxB;
}

/*
  Full Subtractor routines     (D means Differece, P means Payback)

  the difference of current bits:   D = A + B + P
  the borrow out of current bits:   Borrow = A*B + B*P + P*A + B + P

  Refer to http://www.doc.ic.ac.uk/~dfg/hardware/HardwareSlides13.pdf
*/

template <typename T>
const T EncNum<T>::subtract_difference(const T & bitA , const T & bitB, const T & bitPayback) const {

    T bitDifference = bitA;
    bitDifference.addCtxt(bitB);
    bitDifference.addCtxt(bitPayback);
    return bitDifference;
}

template <typename T>
const T EncNum<T>::subtract_borrow(const T & bitA, const T & bitB, const T & bitPayback) const  {

    T bitAxB = bitA;
    bitAxB.multiplyBy(bitB);
    T bitBxP = bitB;
    bitBxP.multiplyBy(bitPayback);
    T bitPxA = bitPayback;
    bitPxA.multiplyBy(bitA);
    // gather the result
    T bitBorrow = bitAxB;
    bitBorrow.addCtxt(bitBxP);
    bitBorrow.addCtxt(bitPxA);
    bitBorrow.addCtxt(bitB);
    bitBorrow.addCtxt(bitPayback);
    return bitBorrow;
}

/* improved one-bit full Subtractor: 
 * the borrow out of current bits:   Borrow = (A + P) * (B + P) + B
 */
template <typename T>
const T EncNum<T>::subtract_borrow_improved(const T & bitA, const T & bitB, const T & bitPayback) const  {

    T bitA_plus_P = bitA;
    bitA_plus_P.addCtxt(bitPayback);
    T bitB_plus_P = bitB;
    bitB_plus_P.addCtxt(bitPayback);
    T bitProd = bitA_plus_P;
    bitProd.multiplyBy(bitB_plus_P);
    // gather the result
    T bitBorrow = bitProd;
    bitBorrow.addCtxt(bitB);
    return bitBorrow;
}

template <typename T>
deque<T> EncNum<T>::subtract(const deque<T> &a, const deque<T>& b) {

    int n = a.size();
    deque<T> res;

    // Do the first bit subtraction without payback
    T bitDifference = subtract_first_difference(a[0], b[0]);
    T bitPayback = subtract_first_borrow(a[0], b[0]);
    res.push_back(bitDifference);

    for(int i = 1; i < n-1; ++i)
    {
        bitDifference = subtract_difference(a[i], b[i], bitPayback);
        //bitPayback = subtract_borrow(a[i], b[i],bitPayback);
        bitPayback = subtract_borrow_improved(a[i], b[i],bitPayback);
        res.push_back(bitDifference);
    }
    bitDifference = subtract_difference(a[n-1], b[n-1], bitPayback);
    res.push_back(bitDifference);

    return res;
}

template <typename T>
deque<T> EncNum<T>::subtract_cla(const deque<T> &a, const deque<T>& b) {
	deque<T> b_inverse = NOT(b);
	deque<T> res = cla_deque(a, b_inverse, false);
	return res;
}

template <typename T>
EncNum<T> & EncNum<T>::operator-=(const EncNum<T> &rhs) {
#ifdef _CLA
	this->vNum = subtract_cla(this->vNum, rhs.vNum);
#else
	this->vNum = subtract(this->vNum, rhs.vNum);
#endif
	return *this;
}

template <typename T>
const EncNum<T> EncNum<T>::operator-(const EncNum<T> &other) const {
    return EncNum(*this) -= other;
}

template <typename T>
const deque<T> EncNum<T>::multiplyOnebit(const T & oneBit) const {

    int n = this->vNum.size();
    deque<T> ctVecRes;
    for (int i = 0; i < n; ++i) {
        T ctTemp = this->vNum[i];
        ctTemp.multiplyBy(oneBit);
        ctVecRes.push_back(ctTemp);
    }
    return ctVecRes;
}

template <typename T>
EncNum<T> & EncNum<T>::operator*=(const EncNum<T> &rhs) {

    int n = this->vNum.size();
    T ct0 = vZero_One[0];
    deque< deque<T> > temp;
    deque<T> row;
    for (int i = 0; i < n; ++i) {
        row = this->multiplyOnebit(rhs.vNum[i]);
        temp.push_back(row);
    }
   
    // since now we have all the middle results
    // add rows
	uint size = temp.size();
	int level = (int)(log2(size));
	int db = 1;
	while(level--) {
		for(uint i = 0; 2*i*db < size; ++i) {
			rca_shift(temp[2*i*db], temp[2*i*db+db], 2*i*db, 2*i*db+db);
		}
		db *= 2;
	}
    *this = EncNum<T>(temp[0]);
    return *this;
}

/*
template <typename T>
EncNum<T> & EncNum<T>::operator*=(const EncNum<T> &rhs) {

    int n = this->vNum.size();
    //T ct0 = this->vNum[0];
    //ct0.addCtxt(ct0);  // we get a ZERO by XOR the bit itself
    T ct0 = vZero_One[0];
    deque< deque<T> > temp;
    deque<T> row;
    for (int i = 0; i < n; ++i) {  ///have problem here
        row = this->multiplyOnebit(rhs.vNum[i]);
        for (int j = 0; j < i; ++j) {
        // shift right
            row.push_front(ct0);
            row.pop_back();
        }
        temp.push_back(row);
    }
    // since now we have all the middle results
    // add rows
    //clock_t t;
	uint size = temp.size() - 1;
	while(size != 0) {
		for(uint i = 0; i <= size/2; ++i) {
			//cout << "num[" << i << "] + num[" << size - i << "] ";
			//t = clock();
			#ifdef _CLA
			temp[i] = cla_deque(temp[i], temp[size - i]);
			// use rca adder
			#else
			temp[i] = rca_deque(temp[i], temp[size - i]);
			#endif
			//t = clock() - t;
			//cout << "costs : " << ((float)t)/CLOCKS_PER_SEC << "s " << endl;
		}
		size = size/2;
	}
    *this = EncNum<T>(temp[0]);
    return *this;
}
*/
template <typename T>
const EncNum<T> EncNum<T>::operator*(const EncNum<T> &other) const {
    return EncNum(*this) *= other;
}

// division
// non-restoring division
template <typename T>
deque<T> EncNum<T>::NOT(const deque<T> a) {
	deque<T> b;
	for(auto iter = a.begin(); iter != a.end(); ++iter) {
		b.push_back(NOT(*iter));
	}
	return b;
}

template <typename T>
T EncNum<T>::NOT(const T a) {
	T b = a;
	b.addCtxt(this->vZero_One[1]);
	return b;
}

template <typename T>
deque<T> EncNum<T>::add1bit(const deque<T>& a, const T& b){
	deque<T> sum;
	int n = a.size();
	sum.push_back(add_first_sum(a[0], b));
	T carryin = add_first_carryout(a[0], b);
	for(int i = 1; i < n; i++) {
		sum.push_back(add_first_sum(a[i], carryin));
		carryin = add_first_carryout(a[i], carryin);
	}
	return sum;
}

template <typename T>
deque<T> EncNum<T>::Cond(const T condBit, deque<T> Vt, deque<T> Vf) {
	int n = Vt.size();
	T cBar = NOT(condBit);
	deque<T> cs(n, condBit);
	deque<T> cBars(n, cBar);
	deque<T> Vres;
	for(int i = 0; i < n; i++) {
		cs[i].multiplyBy(Vt[i]);
		cBars[i].multiplyBy(Vf[i]);
		Vres.push_back(add_first_sum(cs[i],cBars[i]));
	}
	return Vres;
}

template <typename T>
deque<T> EncNum<T>::divide(const deque<T> &a, const deque<T> &b, deque<T> &R) {
	int n = a.size();
	deque<T> Q;
	deque<T> Bfly;
	R = subtract(R, b);
	Q.push_front(NOT(R[n-1]));
	deque<T> minusB = add1bit(NOT(b),vZero_One[1]);
	for(int i = n - 2; i >= 0; i--) {
		Bfly = Cond(R[n-1], b, minusB); 
		R.pop_back();
		R.push_front(a[i]);
		R = rca_deque(R, Bfly);
		Q.push_front(NOT(R[n-1]));
	}
	deque<T> zero(n, vZero_One[0]);
	Bfly = Cond(R[n-1], b, zero);
	R = rca_deque(R, Bfly);
	return Q;
}


template <typename T>
EncNum<T> & EncNum<T>::DivWithReminder(const EncNum<T> &a1, const EncNum<T> &a2, EncNum<T> &R) {
	this->vNum = divide(a1.vNum, a2.vNum, R.vNum);
	return *this;
}

template <typename T>
EncNum<T> & EncNum<T>::operator/=(const EncNum<T> &rhs) {
	int n = this->vNum.size();
	deque<T> zero(n, vZero_One[0]);
	this->vNum = divide(this->vNum, rhs.vNum, zero);
	return *this;
}

template <typename T>
const EncNum<T> EncNum<T>::operator/(const EncNum<T> &other) const {
    return EncNum(*this) /= other;
}


//
template <typename T>
EncNum<T>& EncNum<T>::operator=(const EncNum<T>& rhs) {
    this->vNum = rhs.vNum;
    return *this;
}

template class EncNum<Ctxt>;
