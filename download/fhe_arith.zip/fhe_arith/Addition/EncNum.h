//  Copyright (C) 2016 Chen Xu
//	Distributed under the terms of the GPLv3 license (see LICENSE file)

/*
    EncNum is used for Binary Arithmetics, particularly designed for
    homomorphic encryption library HElib, you can try this along with
    Ctxt class in HElib.
*/

#ifndef _ENCNUM_H_
#define _ENCNUM_H_

#pragma once
#include <deque>
#include "FHE.h"
#include "EncryptedArray.h"
using namespace std;

//extern const int bitN;

template <typename T>
class EncNum {

    public:
        //constructor
        EncNum(){}
        EncNum(const deque<T> &vecNum) : vNum(vecNum)  {}
        void init(const deque<T> & vecNum) {this->vNum = vecNum;}

        //pass the encrypted one and encrypted zero to EncNum
        void setOne(const deque<T> &vecZero_One) {this->vZero_One = vecZero_One;}
		
		//get the deque of ciphertext
        const deque<T> getVec() const {return this->vNum;}
        
        //return the length of the deque
        const int size() const {return this->vNum.size(); }

        //assignment operator
        EncNum<T>& operator=(const EncNum<T> &rhs);

        //binary arithmetic operators
        const EncNum<T> operator+(const EncNum<T> &other) const;
        const EncNum<T> operator-(const EncNum<T> &other) const;
        const EncNum<T> operator*(const EncNum<T> &other) const;
        const EncNum<T> operator/(const EncNum<T> &other) const;

        //compound assignment operators
        EncNum<T> & operator+=(const EncNum<T> &rhs);
        EncNum<T> & operator-=(const EncNum<T> &rhs);
        EncNum<T> & operator*=(const EncNum<T> &rhs);
        EncNum<T> & operator/=(const EncNum<T> &rhs);
        EncNum<T> & DivWithReminder(const EncNum<T> &a1, const EncNum<T> &a2, EncNum<T> &R);
        
    private:
        // data
        deque<T> vNum;
        deque<T> vZero_One;

		//Helper functions
        //Addition
        const T add_first_sum(const T & bitA, const T & bitB) const;
        const T add_first_carryout(const T & bitA, const T & bitB) const;
        const T add_sum(const T & bitA ,const T & bitB, const T & bitCin) const;
        const T add_carryout(const T & bitA,const T & bitB, const T & bitCin) const;
		const T add_carryout_improved(const T & bitA,const T & bitB,const T & bitCin) const;        
		
	
		//CLA adder
        void CalculateCarryin(const deque<T>& gp, deque<T>& Cin, int size);
        const deque<T> recursiveGP(const deque<T> &gp);
		deque<T> cla_deque(const deque<T>& a, const deque<T>& b, bool add = true);
		deque<T> rca_deque(const deque<T>& a, const deque<T>& b);
		void rca_shift(deque<T>& a, const deque<T>& b, int shift1, int shift2);
        //subtraction
        const T subtract_first_difference(const T & bitA, const T & bitB) const;
        const T subtract_first_borrow(const T & bitA, const T & bitB) const;
        const T subtract_difference(const T & bitA , const T & bitB, const T & bitPayback) const;
        const T subtract_borrow(const T & bitA, const T & bitB, const T & bitPayback) const;
        const T subtract_borrow_improved(const T & bitA, const T & bitB, const T & bitPayback) const;
        deque<T> subtract_cla(const deque<T> &a, const deque<T>& b);
		
		deque<T> subtract(const deque<T> &a, const deque<T>& b);

        //multiplication
        const deque<T> multiplyOnebit(const T & oneBit) const;
        
        // helper for division
        T NOT(const T a);
        deque<T> NOT(const deque<T> a);		
		deque<T> addWithoutCarryin(const deque<T>& a, const deque<T>& b);
		deque<T> add1bit(const deque<T>& a, const T& b);        
        deque<T> Cond(const T condBit, deque<T> Vt, deque<T> Vf);
        //deque<T> divide(deque<T> &a, deque<T> &b);        
        deque<T> divide(const deque<T> &a, const deque<T> &b, deque<T> &R);


};

#endif
